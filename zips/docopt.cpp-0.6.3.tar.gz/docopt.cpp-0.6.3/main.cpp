//
//  main.cpp
//  docopt
//
//  Created by Jared Grubb on 2013-10-03.
//  Copyright (c) 2013 Jared Grubb. All rights reserved.
//

#include "docopt.h"

int main(int argc, const char * argv[])
{
	
	return 0;
}

